#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    grupoTamaño = new QButtonGroup(this);

    grupoTamaño->addButton(ui->radioButton, 1);
    grupoTamaño->addButton(ui->radioButton_2, 2);
    grupoTamaño->addButton(ui->radioButton_3, 3);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString pedido;
    QString tamano;
    QString bebida = ui->comboBox->currentText();
    int selectTamaño = grupoTamaño->checkedId();
    if (selectTamaño == -1) {
            QMessageBox:: warning(this, "Error", "Debe seleccionar un tamaño.");
            return;
        }
    switch (selectTamaño) {
        case 1:
            tamano = ui->radioButton->text();
            break;
        case 2:
            tamano = ui->radioButton_2->text();
            break;
        case 3:
            tamano = ui->radioButton_3->text();
            break;
        }

        pedido = QString("Ha seleccionado: \nBebida: %1\nTamaño: %2").arg(bebida).arg(tamano);
        ui->label->setText(pedido);
}

